# -*- coding: utf-8 -*-

"""MMUQ Assignment 01: HBV001A calibration with differential evolution."""

from __future__ import annotations

import io
import os
import sys
from contextlib import redirect_stdout
from pathlib import Path

import matplotlib

SHOW_PLOTS = os.environ.get("HBV_SHOW_PLOTS", "1") != "0"
if SHOW_PLOTS and sys.platform == "darwin":
    matplotlib.use("macosx")
matplotlib.rcParams["figure.raise_window"] = True

import matplotlib.pyplot as plt
from matplotlib.dates import AutoDateLocator, ConciseDateFormatter
import numpy as np
import pandas as pd
from scipy.optimize import differential_evolution

from hmg import HBV001A


MAIN_DIR = Path(__file__).resolve().parent / "data"
TIME_SERIES_FILE = "time_series___24163005.csv"
AREA_FILE = "area___24163005.csv"
RESULTS_DIR = Path(__file__).resolve().parent / "results"

RANDOM_SEED = 42
DE_MAXITER = 300
DE_POPSIZE = 8
DE_TOLERANCE = 1.0e-3
DE_POLISH = False

# Moodle: Model Parameter Bounds for Optimization (model_parameter_bounds.png).
PARAMETER_BOUNDS = {
    "snw_dth": (0.0, 10.0),
    "snw_att": (-2.0, 3.0),
    "snw_pmf": (0.0, 3.0),
    "snw_amf": (0.0, 10.0),
    "sl0_dth": (0.0, 50.0),
    "sl0_pwp": (5.0, 700.0),
    "sl0_fcy": (100.0, 700.0),
    "sl0_bt0": (0.01, 10.0),
    "urr_dth": (0.0, 10.0),
    "lrr_dth": (0.0, 50.0),
    "urr_wsr": (0.0, 1.0),
    "urr_ulc": (0.0, 1.0),
    "urr_tdh": (0.0, 200.0),
    "urr_tdr": (0.01, 1.0),
    "urr_ndr": (0.0, 0.1),
    "urr_uct": (0.0, 0.1),
    "lrr_dre": (0.0, 0.01),
    "lrr_lct": (0.0, 0.01),
}


def _assert_float_series(name: str, values: np.ndarray, nonnegative: bool = False) -> None:
    assert isinstance(values, np.ndarray), (name, type(values))
    assert values.ndim == 1, (name, values.ndim)
    assert values.size > 0, (name, values.size)
    assert np.issubdtype(values.dtype, np.floating), (name, values.dtype)
    assert np.isfinite(values).all(), name
    if nonnegative:
        assert (values >= 0.0).all(), name


def _load_data(main_dir: Path) -> tuple[pd.DataFrame, float, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    assert main_dir.is_dir(), main_dir
    time_series_path = main_dir / TIME_SERIES_FILE
    area_path = main_dir / AREA_FILE
    assert time_series_path.is_file(), time_series_path
    assert area_path.is_file(), area_path

    input_frame = pd.read_csv(time_series_path, sep=";", index_col=0)
    required_columns = ("tavg__ref", "pptn__ref", "petn__ref", "diso__ref")
    assert all(column in input_frame.columns for column in required_columns), input_frame.columns
    input_frame.index = pd.to_datetime(input_frame.index, format="%Y-%m-%d-%H")
    assert not input_frame.empty, "Input time series is empty."
    assert not input_frame.index.hasnans, "Input timestamps contain NaT."
    assert input_frame.index.is_unique, "Input timestamps are duplicated."
    assert input_frame.index.is_monotonic_increasing, "Input timestamps are not ordered."
    assert (input_frame.index[1:] - input_frame.index[:-1] == pd.Timedelta(hours=1)).all(), (
        "Input timestamps must have a continuous hourly time step."
    )

    tems = input_frame["tavg__ref"].to_numpy(dtype=np.float64)
    ppts = input_frame["pptn__ref"].to_numpy(dtype=np.float64)
    pets = input_frame["petn__ref"].to_numpy(dtype=np.float64)
    observed = input_frame["diso__ref"].to_numpy(dtype=np.float64)

    _assert_float_series("temperature", tems)
    _assert_float_series("precipitation", ppts, nonnegative=True)
    _assert_float_series("potential evapotranspiration", pets, nonnegative=True)
    _assert_float_series("observed discharge", observed, nonnegative=True)
    assert tems.size == ppts.size == pets.size == observed.size, (
        tems.size, ppts.size, pets.size, observed.size
    )
    with np.errstate(divide="raise", invalid="raise", over="raise"):
        observed_variation = float(np.sum((observed - np.mean(observed)) ** 2))
    assert np.isfinite(observed_variation) and observed_variation > 0.0, (
        "Observed discharge must have positive finite variation for NSE."
    )

    area_frame = pd.read_csv(area_path, sep=";", index_col=0)
    assert area_frame.size >= 1, area_frame.shape
    catchment_area = float(area_frame.iloc[0, 0])
    assert np.isfinite(catchment_area), catchment_area
    assert catchment_area > 0.0, catchment_area
    return input_frame, catchment_area, tems, ppts, pets, observed


def _validate_parameter_vector(
    parameters: np.ndarray,
    bounds: np.ndarray,
    parameter_count: int,
) -> np.ndarray:
    assert isinstance(parameters, np.ndarray), type(parameters)
    assert parameters.ndim == 1, parameters.ndim
    assert parameters.size == parameter_count, (parameters.size, parameter_count)
    assert np.issubdtype(parameters.dtype, np.floating), parameters.dtype
    assert np.isfinite(parameters).all(), parameters
    assert np.all(parameters >= bounds[:, 0]), parameters
    assert np.all(parameters <= bounds[:, 1]), parameters
    parameters32 = parameters.astype(np.float32)
    assert np.isfinite(parameters32).all(), parameters32
    return parameters32


class EvaluationTracker:
    def __init__(self) -> None:
        self.parameter_vectors: list[np.ndarray] = []
        self.objective_values: list[float] = []
        self.best_running_values: list[float] = []
        self.best_parameters: np.ndarray | None = None
        self.best_objective_value = np.inf

    def record(self, parameters: np.ndarray, objective_value: float) -> None:
        parameters_copy = parameters.astype(np.float64, copy=True)
        objective_value = float(objective_value)
        self.parameter_vectors.append(parameters_copy)
        self.objective_values.append(objective_value)
        if objective_value < self.best_objective_value:
            self.best_objective_value = objective_value
            self.best_parameters = parameters_copy.copy()
        self.best_running_values.append(float(self.best_objective_value))


def _objective_function(
    parameters: np.ndarray,
    model: HBV001A,
    observed: np.ndarray,
    bounds: np.ndarray,
    tracker: EvaluationTracker,
) -> float:
    """Return 1 - NSE for one sampled parameter vector."""

    model_parameters = _validate_parameter_vector(
        parameters,
        bounds,
        parameter_count=len(model.get_parameter_labels()),
    )
    with np.errstate(divide="raise", invalid="raise", over="raise"):
        model.set_parameters(model_parameters)
        # oflg=1 reuses one output row and starts at the same initial state at
        # t == 0 for every call. No reset is needed inside the DE loop.
        with redirect_stdout(io.StringIO()):
            model.run_model()
        simulated = np.asarray(model.get_discharge(), dtype=np.float64).copy()
        assert simulated.shape == observed.shape, (simulated.shape, observed.shape)
        assert np.isfinite(simulated).all(), simulated

        observed_anomaly = observed - float(np.mean(observed))
        denominator = float(np.sum(observed_anomaly * observed_anomaly))
        assert np.isfinite(denominator) and denominator > 0.0, denominator
        residuals = simulated - observed
        objective_value = float(np.sum(residuals * residuals) / denominator)
        assert np.isfinite(objective_value), objective_value
    tracker.record(parameters, objective_value)
    return objective_value


def _make_figures(
    input_frame: pd.DataFrame,
    model: HBV001A,
    simulated: np.ndarray,
    observed: np.ndarray,
    tracker: EvaluationTracker,
    parameter_labels: list[str],
) -> list[plt.Figure]:
    figures: list[plt.Figure] = []
    output_labels = model.get_output_labels()
    evaluations = np.arange(1, len(tracker.objective_values) + 1)
    parameter_history = np.vstack(tracker.parameter_vectors)
    objective_values = np.asarray(tracker.objective_values, dtype=float)
    best_running_values = np.asarray(tracker.best_running_values, dtype=float)

    figure = plt.figure(figsize=(11, 5), dpi=120, layout="constrained")
    plt.plot(input_frame.index, observed, label="Observed", alpha=0.8)
    plt.plot(input_frame.index, simulated, label="Optimized HBV001A", alpha=0.8)
    plt.grid()
    plt.legend()
    plt.xlabel("Time")
    plt.ylabel(r"Discharge [$\mathrm{m^3\,s^{-1}}$]")
    plt.title("Observed and optimized simulated hydrograph")
    locator = AutoDateLocator(minticks=4, maxticks=7)
    plt.gca().xaxis.set_major_locator(locator)
    plt.gca().xaxis.set_major_formatter(ConciseDateFormatter(locator))
    figures.append(figure)

    ncols = 3
    nrows = int(np.ceil(len(parameter_labels) / ncols))
    figure, axes = plt.subplots(
        nrows, ncols, figsize=(12, 2.6 * nrows), dpi=120, layout="constrained"
    )
    axes = np.atleast_1d(axes).ravel()
    for index, label in enumerate(parameter_labels):
        axes[index].scatter(parameter_history[:, index], objective_values, s=5, alpha=0.4)
        axes[index].set_xlabel(label)
        axes[index].set_ylabel(r"$\mathrm{OFV} = 1 - \mathrm{NSE}$")
        axes[index].grid()
    for axis in axes[len(parameter_labels):]:
        axis.set_visible(False)
    figure.suptitle("Sampled parameter vectors versus objective value")
    figures.append(figure)

    figure, axes = plt.subplots(
        nrows + 1, ncols, figsize=(12, 2.6 * (nrows + 1)),
        dpi=120, sharex=True, layout="constrained"
    )
    axes = np.atleast_1d(axes).ravel()
    for index, label in enumerate(parameter_labels):
        axes[index].plot(evaluations, parameter_history[:, index], linewidth=0.7)
        axes[index].set_ylabel(label)
        axes[index].grid()
    ofv_axis = axes[len(parameter_labels)]
    ofv_axis.plot(evaluations, objective_values, alpha=0.35, label="OFV")
    ofv_axis.plot(evaluations, best_running_values, linewidth=1.5, label="Best running OFV")
    ofv_axis.set_ylabel("OFV")
    ofv_axis.set_xlabel("Objective-function evaluation")
    ofv_axis.legend()
    ofv_axis.grid()
    for axis in axes[len(parameter_labels) + 1:]:
        axis.set_visible(False)
    figure.suptitle("Differential-evolution parameter and OFV evolution")
    figures.append(figure)

    figure, axes = plt.subplots(
        8, 1, figsize=(9, 13), dpi=120, sharex=True, layout="constrained"
    )
    axes_tem, axes_ppt, axes_snw, axes_sl0, axes_etn, axes_rrr, axes_rnf, axes_bal = axes
    axes_tem.plot(input_frame["tavg__ref"], alpha=0.85)
    axes_tem.set_ylabel(r"TEM [$^{\circ}\mathrm{C}$]")
    axes_ppt.plot(input_frame["pptn__ref"], alpha=0.85)
    axes_ppt.set_ylabel(r"PPT [$\mathrm{mm\,h^{-1}}$]")
    outputs = model.get_outputs()
    axes_snw.plot(input_frame.index, outputs[:, output_labels["snw_dth"]], alpha=0.85)
    axes_snw.set_ylabel(r"SNW [$\mathrm{mm}$]")
    axes_sl0.plot(input_frame.index, outputs[:, output_labels["sl0_dth"]], alpha=0.85)
    axes_sl0.set_ylabel(r"SL0 [$\mathrm{mm}$]")
    axes_etn.plot(input_frame.index, input_frame["petn__ref"], label="PET", alpha=0.85)
    axes_etn.plot(input_frame.index, outputs[:, output_labels["sl0_etn"]], label="ETN", alpha=0.85)
    axes_etn.set_ylabel(r"ETN [$\mathrm{mm\,h^{-1}}$]")
    axes_etn.legend()
    axes_rrr.plot(input_frame.index, outputs[:, output_labels["urr_dth"]], label="URR", alpha=0.85)
    axes_rrr.plot(input_frame.index, outputs[:, output_labels["lrr_dth"]], label="LRR", alpha=0.85)
    axes_rrr.set_ylabel(r"DTH [$\mathrm{mm}$]")
    axes_rrr.legend()
    axes_rnf.plot(input_frame.index, outputs[:, output_labels["chn_pow"]], label="SFC", alpha=0.85)
    axes_rnf.plot(
        input_frame.index,
        outputs[:, output_labels["urr_urf"]] + outputs[:, output_labels["lrr_lrf"]],
        label="GND",
        alpha=0.85,
    )
    axes_rnf.set_ylabel(r"RNF [$\mathrm{mm\,h^{-1}}$]")
    axes_rnf.legend()
    axes_bal.plot(input_frame.index, outputs[:, output_labels["mod_bal"]], alpha=0.85)
    axes_bal.set_ylabel(r"BAL [$\mathrm{mm\,h^{-1}}$]")
    for axis in axes:
        axis.grid()
    axes[-1].set_xlabel("Time")
    locator = AutoDateLocator(minticks=4, maxticks=6)
    axes[-1].xaxis.set_major_locator(locator)
    axes[-1].xaxis.set_major_formatter(ConciseDateFormatter(locator))
    figure.suptitle("Inputs and internally simulated HBV001A variables")
    figures.append(figure)
    return figures


def _save_results(
    figures: list[plt.Figure],
    tracker: EvaluationTracker,
    parameter_labels: list[str],
    result,
) -> None:
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    names = (
        "hydrograph.png",
        "parameter_vs_ofv.png",
        "optimization_evolution.png",
        "internal_variables.png",
    )
    for figure, name in zip(figures, names):
        figure.savefig(RESULTS_DIR / name, bbox_inches="tight")

    summary = pd.DataFrame({
        "parameter": parameter_labels,
        "best_value": np.asarray(result.x, dtype=float),
    })
    summary.to_csv(RESULTS_DIR / "best_parameters.csv", index=False)
    np.savez(
        RESULTS_DIR / "optimization_trace.npz",
        parameter_vectors=np.vstack(tracker.parameter_vectors),
        objective_values=np.asarray(tracker.objective_values, dtype=float),
        best_running_values=np.asarray(tracker.best_running_values, dtype=float),
        optimizer_success=bool(result.success),
        optimizer_message=str(result.message),
        iterations=int(result.nit),
        evaluations=int(result.nfev),
    )


def main() -> None:
    input_frame, catchment_area, tems, ppts, pets, observed = _load_data(MAIN_DIR)
    time_steps = int(tems.size)
    discharge_scaler = catchment_area / (3600.0 * 1000.0)
    assert np.isfinite(discharge_scaler) and discharge_scaler > 0.0, discharge_scaler

    model = HBV001A()
    model.set_inputs(tems, ppts, pets)
    model.set_outputs(time_steps)
    model.set_discharge_scaler(float(discharge_scaler))
    model.set_optimization_flag(1)

    parameter_labels_by_name = model.get_parameter_labels()
    parameter_labels = [
        label for label, _ in sorted(parameter_labels_by_name.items(), key=lambda item: item[1])
    ]
    bounds = model.get_parameter_bounds_in_correct_order(PARAMETER_BOUNDS)
    assert bounds.shape == (len(parameter_labels), 2), bounds.shape
    assert np.isfinite(bounds).all(), bounds
    assert np.all(bounds[:, 0] <= bounds[:, 1]), bounds

    tracker = EvaluationTracker()
    objective = lambda parameters: _objective_function(
        parameters, model, observed, bounds, tracker
    )

    print(f"Input time steps: {time_steps}")
    print(f"Catchment area [m2]: {catchment_area:.4f}")
    print(f"Discharge scaler [m3/s per mm/h]: {discharge_scaler:.8f}")
    print(f"DE evaluations are tracked in memory; maxiter={DE_MAXITER}, popsize={DE_POPSIZE}.")

    result = differential_evolution(
        objective,
        bounds=[(float(lower), float(upper)) for lower, upper in bounds],
        seed=RANDOM_SEED,
        maxiter=DE_MAXITER,
        popsize=DE_POPSIZE,
        tol=DE_TOLERANCE,
        polish=DE_POLISH,
        workers=1,
        updating="immediate",
        disp=True,
    )
    assert np.isfinite(result.fun), result.message
    assert tracker.best_parameters is not None
    assert len(tracker.parameter_vectors) == result.nfev, (
        len(tracker.parameter_vectors), result.nfev
    )

    best_parameters = _validate_parameter_vector(result.x, bounds, len(parameter_labels))
    model.set_parameters(best_parameters)
    model.set_outputs(time_steps)
    model.set_optimization_flag(0)
    with redirect_stdout(io.StringIO()):
        model.run_model()
    simulated = np.asarray(model.get_discharge(), dtype=np.float64).copy()
    outputs = np.asarray(model.get_outputs(), dtype=np.float64)
    assert np.isfinite(simulated).all(), simulated
    assert np.isfinite(outputs).all(), outputs
    assert simulated.shape == observed.shape, (simulated.shape, observed.shape)

    figures = _make_figures(input_frame, model, simulated, observed, tracker, parameter_labels)
    _save_results(figures, tracker, parameter_labels, result)

    print(f"Best OFV (1 - NSE): {float(result.fun):.8f}")
    print(f"NSE: {1.0 - float(result.fun):.8f}")
    print(f"Tracked parameter vectors: {len(tracker.parameter_vectors)}")
    print(f"Optimizer converged: {bool(result.success)}")
    print(f"Termination: {result.message}")
    print(f"Iterations: {result.nit}; objective evaluations: {result.nfev}")
    print(f"Results directory: {RESULTS_DIR}")

    if SHOW_PLOTS:
        plt.show(block=True)
    for figure in figures:
        plt.close(figure)


if __name__ == "__main__":
    main()
