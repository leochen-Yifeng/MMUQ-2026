# Assignment 1 — Part 1 Speaking Script

Estimated speaking time: approximately 5–6 minutes. Adjust the pace to fit the full group presentation.

## Slide 1 — Assignment 1

Good morning, everyone. In this presentation, we investigate the calibration of the HBV rainfall–runoff model and the effects of switching off selected model processes.

I will first introduce the calibration method and our baseline result. Then I will show how the optimization behaves when we use different random seeds.

## Slide 2 — Research question and approach

Our first question is: how can we calibrate the HBV model to fit the observed discharge? We search for a set of parameters that gives a good fit, and use the calibrated model as our baseline.

Our second question is: how does the simulation change when selected model processes are switched off? To investigate this, we compare discharge and internal storage with the calibrated baseline.

## Slide 3 — Calibration objective

The model uses the supplied temperature, precipitation and potential evapotranspiration data to simulate discharge.

To evaluate the simulation, we compare simulated discharge with observed discharge using the Nash–Sutcliffe efficiency, or NSE. An NSE of one represents a perfect match, while larger errors lead to a lower NSE.

Since the optimization algorithm minimizes an objective function, we use one minus NSE. Therefore, an objective value closer to zero indicates a better fit.

The objective uses squared errors, so larger discharge errors have a stronger influence on the result.

## Slide 4 — Differential Evolution

For the calibration, we use Differential Evolution, a population-based optimization algorithm.

The algorithm starts with a population of candidate parameter vectors within the specified bounds. Each vector represents one possible configuration of the HBV model.

For every candidate, we run the model and calculate the objective value. The algorithm then generates new trial vectors, compares their performance with existing candidates, and retains better solutions.

This process continues until a stopping criterion is satisfied.

## Slide 5 — Optimization history and convergence

This figure shows an example of the optimization history from our independent run with random seed 42.

Each grey point represents one evaluated candidate. The blue line shows the best objective value found up to that point.

Individual candidates can perform worse than earlier ones, but the best value found so far can only decrease or stay the same.

The algorithm stops when its convergence criterion is satisfied. This means the search has met the chosen stopping condition, but it does not by itself prove that the result is the global optimum.

## Slide 6 — Multiple random seeds

Because Differential Evolution involves randomness, we repeated the calibration using four different random seeds.

We kept the data, parameter bounds, objective function and optimization settings the same. Only the random seed changed.

All four runs satisfied their stopping criterion. Their final MSE values are close: approximately 61.55 to 61.83, and their NSE values are all around 0.907.

Here, MSE is the mean squared difference between simulated and observed discharge. Since all runs use the same observations, minimizing MSE gives the same ranking as minimizing one minus NSE.

The similar results increase our confidence that the optimization reaches a good solution consistently. However, they do not prove that it is the global optimum.

## Slide 7 — Parameter values and MSE: snow and soil

The next three slides show the relationship between individual parameter values and MSE.

In each panel, the horizontal axis shows one parameter value and the vertical axis shows MSE. The colours represent the four random seeds. Each point is a parameter vector evaluated during optimization, and the stars mark the best result from each run.

The vertical axis uses a logarithmic scale, which helps us see both high-error candidates and the lower-error region.

## Slide 8 — Parameter values and MSE: soil and reservoirs

Here we continue with the soil and reservoir parameters.

Across the four runs, the best solutions reach a similar MSE region. The plots also show the range of parameter values explored during the search.

Each panel displays only one parameter at a time. The other parameters also change between candidates, so a panel should not be interpreted as a separate experiment on that parameter alone.

## Slide 9 — Parameter values and MSE: reservoir pathways

The final set of panels shows the remaining reservoir parameters.

Together, the three figures show that the four optimization runs explore the parameter space and reach similar objective values. These points are the candidates sampled by the optimization algorithm; they are not samples from a posterior distribution.

We can therefore say that the results are consistent across these four runs, while keeping the global-optimum claim cautious.

## Slide 10 — Calibrated baseline

Finally, this is the baseline hydrograph used in the group's process comparisons. The blue line is the observed discharge, and the orange line is the calibrated simulation.

The baseline NSE is approximately 0.907, the RMSE is 7.85 cubic metres per second, and the volume bias is minus 4.1 percent.

The model follows the overall hydrograph reasonably well, although it underestimates the second large January peak.

We use this calibrated model as the reference for the process-switching experiments.

## Note for the speaker

Slide 5 shows our independent seed 42 optimization history. Slide 10 shows the baseline hydrograph from the group's Part 4 slides, which the teammate identified as a seed 43 run. The two are distinct runs.
