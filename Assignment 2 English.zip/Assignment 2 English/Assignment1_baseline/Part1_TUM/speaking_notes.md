# Part 1 speaking notes (approximately 4–5 minutes)

## Slide 1 — Hydrological Model Process Tests (20 seconds)
Today we investigate how a calibrated hydrological model responds when selected processes are switched off. I will introduce the calibration and the baseline. The following sections look at the process experiments.

## Slide 2 — Research question and approach (35 seconds)
We first calibrate HBV001a using observed discharge. The calibrated model provides a reference. We then turn selected processes off and compare their discharge and storage responses. This lets us examine how the model behaves when particular pathways are removed.

## Slide 3 — Calibration objective (55 seconds)
The supplied inputs include temperature, precipitation and potential evapotranspiration. For each parameter vector, the model produces simulated discharge. We compare it with observed discharge using NSE. Since the optimizer minimizes a function, we use one minus NSE. Zero represents a perfect match. Squared errors give greater weight to larger discrepancies, so peak errors can strongly affect the objective.

## Slide 4 — Differential Evolution (1 minute)
Differential Evolution starts with a population of parameter vectors within specified bounds. Each vector represents a possible model configuration. We run HBV for each candidate and evaluate its objective. The algorithm generates trial vectors from the population and compares them with existing candidates. Better candidates are retained and the process continues until a stopping criterion is met.

## Slide 5 — Optimization history and convergence (1 minute)
The grey points show all candidate evaluations, and the blue curve shows the lowest objective found so far. Individual trials can be worse, whereas the best-so-far value can only improve or remain unchanged. This particular chart comes from our separate seed 42 run and illustrates how the optimization progressed; it is not the search history of the group's seed 43 baseline. Stopping means the algorithm's convergence criterion has been met. It does not by itself prove a global optimum or that the parameter vector is unique.

## Slide 6 — Calibrated baseline (1 minute)
The figure and performance metrics here are taken from the group's Part 4 slides. The observed discharge is blue and the calibrated simulation is orange. The baseline NSE is approximately 0.907, rounded to three decimals, with RMSE of 7.85 cubic metres per second and volume bias of minus 4.1 percent. The overall fit is good, although the model misses part of the second large January peak. This baseline provides the reference for the process experiments. The next speaker will begin with snow.

## Consistency note
The optimization chart shows the separate seed 42 run (NSE 0.906972...). The group's baseline is reported as seed 43 (NSE 0.9071412356 in the teammate's message). Both round to 0.907, but they are distinct runs. The underlying group seed 43 history and configuration have not been supplied. The figure and reported RMSE and volume bias on slide 6 come from the group's Part 4 file.
