# Four-person presentation outline, approximately 20 minutes

Allow roughly five minutes per person. If the 20-minute slot includes questions, combine slides 16-18 and reserve three minutes for discussion. These are prompts rather than a script.

## Speaker 1: Question, calibration, and baseline, slides 1-6

1. Ask how simulated discharge and storage in the calibrated HBV model change when selected processes are switched off.
2. Introduce the baseline, the three switch-off experiments, and the comparison and limitations.
3. Faizan supplied the model and forcing data. We calibrated 18 entries including initial storages using differential evolution (DE), with 1 - NSE as the objective. Squared errors give greater weight to large discharge errors.
4. Gray points show tested parameter vectors and the blue line shows the best objective found so far. DE proposes candidates and evaluates the model; individual trials can worsen, whereas the running best can only decrease or remain unchanged. After the first candidate, the best value improved 61 times.
5. The convergence plot shows the ratio of the population objective standard deviation to the stopping threshold. The run stops at or below 1. At generation 263 the standard deviation was about 0.00009095 and the threshold about 0.00009322. There were 38,016 evaluations; the objective was 0.0930 and NSE 0.907. Convergence does not prove a global optimum or unique parameters.
6. Baseline NSE is 0.907, RMSE is 7.86 m³/s, and volume bias is -5.0%. The hydrograph generally follows observations but some peaks remain inaccurate. The full period was calibrated; it is not independent validation.

## Speaker 2: Experiment design and snowmelt, slides 7-11

7. At the time of the largest observed peak, observed discharge is 153.5 m³/s and the baseline is 105.1 m³/s. These are values at the same time, not the separate maxima of both series.
8. Switch off one parameter group at a time, keeping other parameters, initial states, and inputs fixed; do not recalibrate. The groups represent snowmelt, selected channel outlets, and subsurface exports.
9. Setting both melt coefficients to zero changes NSE from 0.907 to 0.414 and volume bias to -43.0%. Under the current parameter vector, switching off melt substantially alters the simulation.
10. At the observed January peak time, the no-melt simulation is about 68.1 m³/s versus 105.1 m³/s in the baseline. Their difference is not a measurement of the actual catchment contribution from snowmelt.
11. Snowfall and accumulation still occur; only the two melt pathways are switched off. Final snow storage is 109.5 mm, versus zero in the baseline, so the complete snow module is not disabled.

## Speaker 3: Reservoir outlets and subsurface flow, slides 12-15

12. Set the upper normal channel-outflow and lower channel-outflow coefficients to zero. The threshold-activated upper fast outlet remains but is not triggered in this run, so simulated channel discharge is zero throughout. NSE can be negative.
13. At the end, lower reservoir storage is 231.5 mm versus about 2.4 mm in the baseline. This is an extreme pathway switch-off experiment; it does not imply water disappears in reality.
14. When upper and lower subsurface exports are switched off, the hydrographs nearly coincide because their calibrated coefficients are already close to zero.
15. The maximum absolute discharge difference is about 0.0233 m³/s. Subsurface exports can change storage and indirectly influence channel flow; their small impact here does not imply the same for every period.

## Speaker 4: Synthesis and discussion, slides 16-19

16. Compare NSE, RMSE, and volume bias. NSE = 0 corresponds to the squared error of predicting the observed mean as a constant; negative values are worse. The first two experiments change strongly; the third changes little.
17. The experiments illustrate snowmelt release, channel outlets, and near-zero export coefficients in this model. They are fixed-parameter model responses, not direct measurements of actual catchment contributions.
18. Other parameters were not recalibrated, so their ability to compensate is unknown. There is no warm-up or independent validation; NSE emphasizes larger errors; and a single converged DE run does not guarantee a global optimum.
19. Invite discussion about recalibrating a simplified model, holding out a validation period, and adding metrics for peaks, volume, and low flows.
