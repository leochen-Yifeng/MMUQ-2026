from pathlib import Path
import sys,json,numpy as np,pandas as pd
from scipy.optimize import differential_evolution
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
# Locate the Assignment 1 baseline and model.
root=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'Assignment1_baseline'))
from ab_calibrate_hbv import load_data,create_model,simulate
from calibration_config import PARAMETER_BOUNDS,WARMUP_STEPS,POPULATION_MULTIPLIER,RANDOM_SEED
p=pd.read_csv(root/'Assignment1_baseline/calibration_outputs/best_parameters.csv');names=p.parameter.tolist();x0=p.best_value.to_numpy();bounds=np.array([PARAMETER_BOUNDS[n] for n in names]);d,area=load_data();m=create_model(d,area);obs=d.diso__ref.to_numpy()[WARMUP_STEPS:];den=np.abs(obs-obs.mean()).sum()
# Define the absolute-error objective; it is not standard NSE.
def obj(x):return float(np.abs(simulate(m,x)[WARMUP_STEPS:]-obs).sum()/den)
n=[0]
def cb(x,convergence):
 n[0]+=1
 if n[0]%50==0:print('generation',n[0],'objective',obj(x),flush=True)
# Run differential evolution from a random population for 700 generations within the original bounds.
r=differential_evolution(obj,bounds,seed=RANDOM_SEED,maxiter=700,popsize=POPULATION_MULTIPLIER,tol=0,atol=0,polish=False,workers=1,callback=cb,strategy='best1bin',updating='immediate',mutation=(.5,1),recombination=.7,init='latinhypercube')
q=simulate(m,r.x);q0=simulate(m,x0);peak=np.argmax(obs);nse=lambda q:1-np.sum((q[WARMUP_STEPS:]-obs)**2)/np.sum((obs-obs.mean())**2)
print('RESULT',json.dumps({'success':bool(r.success),'message':str(r.message),'generations':r.nit,'evaluations':r.nfev,'objective_original':obj(x0),'objective_new':obj(r.x),'NSE_original':nse(q0),'NSE_new':nse(q),'observed_peak':float(obs[peak]),'original_at_peak':float(q0[peak]),'new_at_peak':float(q[peak])}),flush=True)
# Plot observed and simulated discharge, including flood-event detail.
fig,axes=plt.subplots(2,1,figsize=(12,7),layout='constrained')
for ax in axes:
 ax.plot(d.index,d.diso__ref,color='black',lw=1,label='Observed');ax.plot(d.index,q0,color='#007fa3',lw=1.2,label='Original NSE calibration');ax.plot(d.index,q,color='#d45516',lw=1.2,label='Absolute-error calibration');ax.grid(alpha=.2);ax.legend();ax.set_ylabel('Discharge (m³/s)')
axes[0].set_title('Original and absolute-error calibrated discharge');axes[1].set_xlim(pd.Timestamp('2011-01-05'),pd.Timestamp('2011-01-21'));axes[1].set_title('January flood events');fig.savefig(str(root/'absolute_de_reproduced_fit.png'),dpi=180)
np.savez(str(root/'absolute_de_reproduced_result.npz'),parameters=r.x,original=x0,simulated=q)
# Test sensitivity of the three parameters around the new vector.
for name in ['sl0_fcy','snw_pmf','lrr_dre']:
 i=names.index(name);v=r.x[i];lo=max(.8*v,bounds[i,0]);hi=min(1.2*v,bounds[i,1]);change=[]
 for z in np.r_[np.linspace(lo,v,11)[:10],np.linspace(v,hi,11)[1:]]:
  x=r.x.copy();x[i]=z;change.append(100*(obj(x)/r.fun-1))
 print('SENSITIVITY',name,'max_abs',np.max(np.abs(change)),'mean_abs',np.mean(np.abs(change)),flush=True)
