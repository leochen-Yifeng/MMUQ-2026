"""Create two readable nine-parameter figures from the sensitivity results."""
from pathlib import Path
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

# Read perturbation results and group parameters in their original order.
root = Path(__file__).resolve().parent
output = root / 'sensitivity_results'
data = pd.read_csv(output / 'perturbations.csv')
groups = list(data.groupby('parameter', sort=False))
# Split the 18 parameters into two nine-panel figures for the report.
for part in range(2):
    fig, axes = plt.subplots(3, 3, figsize=(12, 10), layout='constrained')
    for ax, (name, group) in zip(axes.flat, groups[part*9:(part+1)*9]):
        ax.plot(group.parameter_change_percent, group.objective_change_percent, '.-', lw=1.1)
        ax.axhline(0, color='gray', lw=.7)
        ax.axvline(0, color='gray', lw=.7)
        ax.set_title(name)
        ax.set_xlabel('Parameter change (%)')
        ax.set_ylabel('Objective change (%)')
        ax.grid(alpha=.25)
    fig.savefig(output / f'perturbation_curves_{part+1}.png', dpi=180)
    plt.close(fig)
