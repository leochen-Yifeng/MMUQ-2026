# Weighted differential evolution, 700 generations

The fit image and run log record the 700-generation experiment. The fixed weights are recomputed by minimax optimization with peak floor 0.7 and nonpeak floor 0.1, as described in the report. The optimizer starts with the original parameter vector among the population, uses seed 42, 700 generations, and disables tolerance-based early stopping. No independent validation was performed.

The run reached its generation limit; it did not meet the normal stopping criterion. The original temporary run did not export its final parameter vector. The included image and log were reproduced by rerunning the same deterministic configuration. Run the companion script from the Assignment 2 folder to reproduce; it recomputes the weights and optimization, prints the results, and saves its image in that folder.
