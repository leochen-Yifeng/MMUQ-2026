"""One-at-a-time perturbations of the saved Assignment 1 calibration."""
# Libraries for numerical calculations, tables, and plots.
from pathlib import Path
import sys

import numpy as np
import pandas as pd
import matplotlib
# Use a non-interactive plotting backend; no plot window is opened.
matplotlib.use('Agg')
import matplotlib.pyplot as plt

# ROOT is the Assignment 2 directory containing this script.
# BASELINE contains the copied Assignment 1 model, data, and calibration results.
ROOT = Path(__file__).resolve().parent
BASELINE = ROOT / 'Assignment1_baseline'
# Import the existing data loading, model creation, and simulation functions.
sys.path.insert(0, str(BASELINE))
from ab_calibrate_hbv import load_data, create_model, simulate
from calibration_config import WARMUP_STEPS


def main():
    # 1. Prepare the output directory and read the calibrated parameters and inputs.
    output = ROOT / 'sensitivity_results'
    output.mkdir(exist_ok=True)
    parameters = pd.read_csv(BASELINE / 'calibration_outputs' / 'best_parameters.csv')
    data, area = load_data()
    model = create_model(data, area)
    # Check parameter order against the model interface to avoid misassigning values.
    labels = sorted(model.get_parameter_labels(), key=model.get_parameter_labels().get)
    if parameters['parameter'].tolist() != labels:
        raise ValueError('Parameter order does not match the model.')
    # x0 is the baseline parameter vector; obs is observed discharge.
    # A WARMUP_STEPS value of zero uses the complete time series.
    x0 = parameters['best_value'].to_numpy(dtype=float)
    obs = data['diso__ref'].to_numpy()[WARMUP_STEPS:]
    # The fixed NSE denominator is the sum of squared deviations from observed mean flow.
    denom = np.sum((obs - obs.mean()) ** 2)

    # 2. Given x, run the model and calculate J = 1 - NSE.
    # A smaller J indicates an overall closer fit to observed discharge for this period.
    def objective(x):
        q = simulate(model, x)[WARMUP_STEPS:]
        return float(np.sum((q - obs) ** 2) / denom)

    # Run the baseline parameters and compare with the saved Assignment 1 objective.
    # Stop if the difference exceeds the specified numerical tolerance.
    baseline = objective(x0)
    import json
    reference = json.loads((BASELINE / 'calibration_outputs' / 'run_summary.json').read_text())['best_objective']
    np.testing.assert_allclose(baseline, reference, rtol=1e-6, atol=1e-10)
    # 3. Perturb parameters one at a time; an empty fixed set includes all 18.
    # Keep every other parameter at its calibrated value.
    records = []
    fixed = set()
    for i, row in parameters.iterrows():
        name = row['parameter']
        if name in fixed:
            continue
        x = x0[i]
        # Change by up to 20% in each direction, stopping at the calibration bounds.
        # Sorting the products correctly handles negative parameters such as snw_att.
        lo = max(min(x * 0.8, x * 1.2), row['lower_bound'])
        hi = min(max(x * 0.8, x * 1.2), row['upper_bound'])
        # Take 10 equally spaced points on each side plus the baseline: 21 in total.
        # The two sides may have different step sizes; [1:] avoids duplicating the baseline.
        values = np.concatenate([np.linspace(lo, x, 11), np.linspace(x, hi, 11)[1:]])
        for value in values:
            # Copy the baseline vector and replace only parameter i before evaluating J.
            # Reuse the existing baseline result rather than rerun the model for that point.
            v = x0.copy()
            v[i] = value
            score = baseline if value == x else objective(v)
            # Record relative changes in the parameter and objective, plus the resulting NSE.
            # All current baseline parameter values and the baseline objective are nonzero.
            records.append({'parameter': name, 'baseline_value': x, 'perturbed_value': value,
                            'parameter_change_percent': 100 * (value - x) / x,
                            'objective_1_minus_nse': score,
                            'objective_change_percent': 100 * (score - baseline) / baseline,
                            'nse': 1 - score})
        print(f'Completed {name}', flush=True)
    # 4. Save the complete result table and baseline metadata; existing files are overwritten.
    # There are 18 parameters with 21 points each, or 378 records including baseline rows.
    results = pd.DataFrame(records)
    results.to_csv(output / 'perturbations.csv', index=False, float_format='%.12g')
    (output / 'baseline.json').write_text(json.dumps({
        'objective_1_minus_nse': baseline, 'nse': 1 - baseline,
        'saved_objective': reference, 'warmup_steps': WARMUP_STEPS,
        'fixed_parameters': sorted(fixed), 'parameter_count': len(parameters),
        'perturbed_parameter_count': len(parameters)-len(fixed),
        'points_per_parameter': 21,
        'sampling': '10 evenly spaced points on each side and the baseline, limited by bounds',
    }, indent=2) + '\n')
    # 5. Plot parameter change (%) against objective change (%) for each parameter.
    # Gray lines mark zero change; a separate script calculates the ranking.
    fig, axes = plt.subplots(6, 3, figsize=(13, 20))
    for ax, (name, group) in zip(axes.flat, results.groupby('parameter', sort=False)):
        ax.plot(group['parameter_change_percent'], group['objective_change_percent'], '.-', lw=1)
        ax.axvline(0, color='grey', lw=.6)
        ax.axhline(0, color='grey', lw=.6)
        ax.set_title(name)
        ax.set_xlabel('Parameter change (%)')
        ax.set_ylabel('Objective change (%)')
        ax.grid(alpha=.25)
    # Hide unused subplots if fewer parameters are included in a future experiment.
    for ax in axes.flat[len(parameters)-len(fixed):]:
        ax.set_visible(False)
    fig.tight_layout()
    fig.savefig(output / 'perturbation_curves.png', dpi=180)
    plt.close(fig)
    print(f'Baseline J={baseline:.10g}; NSE={1-baseline:.10g}', flush=True)


# Run main only when this file is executed directly, not when imported.
if __name__ == '__main__':
    main()
