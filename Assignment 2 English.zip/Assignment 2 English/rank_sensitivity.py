"""Rank existing one-at-a-time experiments by average absolute objective change."""
from pathlib import Path
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

root = Path(__file__).resolve().parent
folder = root / 'sensitivity_results'
# Read perturbation results, exclude baseline points, and calculate mean and maximum changes.
data = pd.read_csv(folder / 'perturbations.csv')
data = data[data['parameter_change_percent'].abs() > 1e-10]
ranking = (data.groupby('parameter', sort=False)
           .agg(mean_absolute_objective_change_percent=('objective_change_percent', lambda x: x.abs().mean()),
                max_absolute_objective_change_percent=('objective_change_percent', lambda x: x.abs().max()),
                min_parameter_change_percent=('parameter_change_percent', 'min'),
                max_parameter_change_percent=('parameter_change_percent', 'max'))
           .sort_values('mean_absolute_objective_change_percent', ascending=False, kind='stable')
           .reset_index())
ranking.insert(0, 'rank', range(1, len(ranking) + 1))
ranking.to_csv(folder / 'sensitivity_ranking.csv', index=False, float_format='%.12g')
# Plot sensitivity ranked by mean absolute relative change.
fig, ax = plt.subplots(figsize=(9, 7))
ax.barh(ranking['parameter'][::-1], ranking['mean_absolute_objective_change_percent'][::-1], color='#32749b')
ax.set_xlabel('Mean absolute objective change (%)')
ax.set_title('Local sensitivity across the available perturbation range')
ax.grid(axis='x', alpha=.25)
fig.tight_layout()
fig.savefig(folder / 'sensitivity_ranking.png', dpi=180)
plt.close(fig)
