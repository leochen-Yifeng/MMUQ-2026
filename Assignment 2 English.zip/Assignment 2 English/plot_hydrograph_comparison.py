"""Compare flow and squared errors for the top three parameters at their endpoints."""
from pathlib import Path
import json
import sys
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.dates as mdates

ROOT = Path(__file__).resolve().parent
BASE = ROOT / 'Assignment1_baseline'
sys.path.insert(0, str(BASE))
from ab_calibrate_hbv import load_data, create_model, simulate
from calibration_config import WARMUP_STEPS


def main():
    # Load the baseline model and observations and prepare the output directory.
    output = ROOT / 'sensitivity_results'
    output.mkdir(exist_ok=True)
    params = pd.read_csv(BASE / 'calibration_outputs' / 'best_parameters.csv')
    data, area = load_data()
    model = create_model(data, area)
    x0 = params.best_value.to_numpy(dtype=float)
    obs = data.diso__ref.to_numpy(dtype=float)
    baseline = simulate(model, x0)
    denom = ((obs[WARMUP_STEPS:] - obs[WARMUP_STEPS:].mean()) ** 2).sum()
    base_sse = (baseline - obs) ** 2
    base_j = base_sse[WARMUP_STEPS:].sum() / denom
    saved = json.loads((BASE / 'calibration_outputs' / 'run_summary.json').read_text())['best_objective']
    np.testing.assert_allclose(base_j, saved, rtol=1e-6)
    previous = pd.read_csv(output / 'perturbations.csv')
    summaries = []
    # Compare simulated discharge at feasible endpoints for the top three parameters.
    for name in ['sl0_fcy', 'snw_pmf', 'lrr_dre']:
        i = params.index[params.parameter == name][0]
        x = x0[i]
        row = params.iloc[i]
        bounds = [max(0.8*x, row.lower_bound), min(1.2*x, row.upper_bound)]
        simulations, sse_changes, labels = [], [], []
        for value in bounds:
            candidate = x0.copy()
            candidate[i] = value
            q = simulate(model, candidate)
            score = ((q[WARMUP_STEPS:] - obs[WARMUP_STEPS:]) ** 2).sum() / denom
            pct = 100 * (value/x - 1)
            old = previous[previous.parameter == name]
            nearest = old.iloc[(old.perturbed_value - value).abs().argmin()]
            np.testing.assert_allclose(score, nearest.objective_1_minus_nse, rtol=1e-6)
            simulations.append(q)
            delta = (q - obs) ** 2 - base_sse
            sse_changes.append(delta)
            labels.append(f'{pct:+.2f}% (J change {(score/base_j-1)*100:+.2f}%)')
            contributing = np.argsort(delta)[-3:][::-1]
            summaries.append({'parameter': name, 'parameter_change_percent': pct,
                              'objective_change_percent': (score/base_j-1)*100,
                              'top_hour_1': str(data.index[contributing[0]]),
                              'top_hour_2': str(data.index[contributing[1]]),
                              'top_hour_3': str(data.index[contributing[2]])})
        # Select a 72-hour window with the greatest combined absolute hourly change
        # in squared error across both endpoint runs; this is a diagnostic zoom.
        # Select the 72-hour window with the greatest combined absolute squared-error changes.
        activity = np.abs(sse_changes[0]) + np.abs(sse_changes[1])
        end = int(np.argmax(np.convolve(activity, np.ones(72), mode='valid'))) + 72
        start = end - 72
        fig, axes = plt.subplots(2, 1, figsize=(12, 6.5), layout='constrained')
        for ax in axes:
            ax.plot(data.index, obs, color='#222222', lw=1.0, label='Observed')
            ax.plot(data.index, baseline, color='#1468a0', lw=1.15, label='Baseline')
            ax.plot(data.index, simulations[0], color='#d56a24', lw=1.1, ls='--', label=labels[0])
            ax.plot(data.index, simulations[1], color='#8d50a0', lw=1.1, ls='-.', label=labels[1])
            ax.set_ylabel('Discharge (m³/s)')
            ax.grid(alpha=.25)
        axes[0].set_title(f'{name}: full period')
        axes[0].legend(ncol=2, fontsize=8, loc='upper left')
        axes[1].set_xlim(data.index[start], data.index[end-1])
        axes[1].xaxis.set_major_formatter(mdates.DateFormatter('%m-%d %H:%M'))
        axes[1].set_title(f'Diagnostic 72-hour window: {data.index[start]:%Y-%m-%d %H:%M} to {data.index[end-1]:%Y-%m-%d %H:%M}')
        axes[1].tick_params(axis='x', rotation=20)
        fig.savefig(output / f'hydrograph_{name}.png', dpi=180)
        plt.close(fig)
        for item in summaries[-2:]:
            item.update(window_start=str(data.index[start]), window_end=str(data.index[end-1]))
        print(name, str(data.index[start]), str(data.index[end-1]), labels)
    pd.DataFrame(summaries).to_csv(output / 'hydrograph_diagnostics.csv', index=False)


if __name__ == '__main__':
    main()
