"""Test combinations of the three top-ranked parameters at feasible endpoints."""
from itertools import combinations, product
from pathlib import Path
import json
import sys
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
BASE = ROOT / 'Assignment1_baseline'
sys.path.insert(0, str(BASE))
from ab_calibrate_hbv import load_data, create_model, simulate
from calibration_config import WARMUP_STEPS


def main():
    # Load the baseline model, data, and parameters.
    parameters = pd.read_csv(BASE / 'calibration_outputs' / 'best_parameters.csv')
    names = parameters['parameter'].tolist()
    top = ['sl0_fcy', 'snw_pmf', 'lrr_dre']
    index = {name: names.index(name) for name in top}
    x0 = parameters['best_value'].to_numpy(dtype=float)
    data, area = load_data()
    model = create_model(data, area)
    obs = data['diso__ref'].to_numpy()[WARMUP_STEPS:]
    denominator = ((obs - obs.mean()) ** 2).sum()

    def evaluate(x):
        return float(((simulate(model, x)[WARMUP_STEPS:] - obs) ** 2).sum() / denominator)

    baseline = evaluate(x0)
    reference = json.loads((BASE / 'calibration_outputs' / 'run_summary.json').read_text())['best_objective']
    np.testing.assert_allclose(baseline, reference, rtol=1e-6, atol=1e-10)
    # Calculate feasible endpoints and the effect of each parameter separately.
    endpoints = {}
    single = {}
    for name in top:
        i = index[name]
        row = parameters.iloc[i]
        endpoints[name] = {'-': max(x0[i] * .8, row['lower_bound']),
                           '+': min(x0[i] * 1.2, row['upper_bound'])}
        for direction, value in endpoints[name].items():
            x = x0.copy()
            x[i] = value
            single[name, direction] = evaluate(x) - baseline
    # Evaluate pairwise and triple combinations against the sum of individual effects.
    records = []
    for size in (2, 3):
        for selected in combinations(top, size):
            for directions in product(('-', '+'), repeat=size):
                x = x0.copy()
                changes = {name: 0.0 for name in top}
                for name, direction in zip(selected, directions):
                    i = index[name]
                    x[i] = endpoints[name][direction]
                    changes[name] = 100 * (x[i] / x0[i] - 1)
                j = evaluate(x)
                delta = j - baseline
                summed = sum(single[name, direction] for name, direction in zip(selected, directions))
                records.append({'parameters': ' + '.join(selected),
                                'directions': ' '.join(directions),
                                **{name + '_change_percent': changes[name] for name in top},
                                'objective': j, 'nse': 1-j,
                                'objective_change_percent': 100 * delta / baseline,
                                'sum_individual_change_percent': 100 * summed / baseline,
                                'interaction_change_percent': 100 * (delta - summed) / baseline,
                                **{name + '_individual_change_percent':
                                   100 * single[name, directions[selected.index(name)]] / baseline if name in selected else 0.0
                                   for name in top}})
    output = ROOT / 'sensitivity_results'
    pd.DataFrame(records).to_csv(output / 'combined_perturbations.csv', index=False, float_format='%.12g')
    print(f'Baseline J={baseline:.10f}, NSE={1-baseline:.10f}; {len(records)} combinations')


if __name__ == '__main__':
    main()
