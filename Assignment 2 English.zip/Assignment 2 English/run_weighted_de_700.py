from pathlib import Path
import os
import sys,numpy as np,pandas as pd
from scipy.optimize import linprog
# Locate the baseline model and import data and simulation functions.
root=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'Assignment1_baseline'))
from ab_calibrate_hbv import load_data,create_model,simulate
from calibration_config import PARAMETER_BOUNDS,WARMUP_STEPS
p=pd.read_csv(root/'Assignment1_baseline/calibration_outputs/best_parameters.csv');names=p.parameter.tolist();x0=p.best_value.to_numpy();d,area=load_data();m=create_model(d,area);obs=d.diso__ref.to_numpy()[WARMUP_STEPS:];q0=simulate(m,x0)[WARMUP_STEPS:];e0=(q0-obs)**2;targets=['sl0_fcy','snw_pmf','lrr_dre'];diff=[];nameset=[]
# Calculate hourly squared-error changes for each target parameter.
for name in targets:
 i=names.index(name);x=x0[i];low,high=PARAMETER_BOUNDS[name];lo=max(.8*x,low);hi=min(1.2*x,high)
 for v in np.r_[np.linspace(lo,x,11)[:10],np.linspace(x,hi,11)[1:]]:
  z=x0.copy();z[i]=v;q=simulate(m,z)[WARMUP_STEPS:];diff.append((q-obs)**2-e0);nameset.append(name)
print('simulations done',flush=True)
D=np.array(diff);n=len(obs);peak=obs>np.quantile(obs,.9);lower=np.where(peak,float(os.environ.get('PEAK_FLOOR','0.7')),float(os.environ.get('OTHER_FLOOR','0.1')))
# Charnes-Cooper: y=w/(e0.w), t=1/(e0.w), s bounds max |D.w|/(e0.w).
# Scale squared errors for numerical stability.
scale=e0.sum(); e=e0/scale;D=D/scale
# variables y[n], t, s. e.y=1; lower*t <= y <= t; |D.y|<=s.
from scipy.sparse import csr_matrix, hstack, vstack, diags
I=diags(np.ones(n),format='csr'); col=lambda a:csr_matrix(np.asarray(a).reshape(-1,1)); zero=csr_matrix((n,1))
# Build the linear program that minimizes maximum relative change under weight bounds.
A=vstack([hstack([I,col(-np.ones(n)),zero]),hstack([-I,col(lower),zero]),hstack([csr_matrix(D),csr_matrix((len(D),1)),col(-np.ones(len(D)))]),hstack([csr_matrix(-D),csr_matrix((len(D),1)),col(-np.ones(len(D)))])],format='csr')
c=np.r_[np.zeros(n+1),1.];eq=csr_matrix(np.r_[e,0,0].reshape(1,-1));res=linprog(c,A_ub=A,b_ub=np.zeros(A.shape[0]),A_eq=eq,b_eq=[1.],bounds=[(0,None)]*(n+2),method='highs')
print('solver',res.success,res.message,flush=True)
if not res.success:raise RuntimeError(res.message)
w=res.x[:n]/res.x[n];print('weight',w.min(),w.max(),'mean',w.mean(),'peakmean',w[peak].mean(),'nonpeakmean',w[~peak].mean(),'near_min',np.mean(w<float(os.environ.get('OTHER_FLOOR','0.1'))+.001),'peak_at_floor',np.mean(w[peak]<float(os.environ.get('PEAK_FLOOR','0.7'))+.001))
for name in targets:
 x=D[np.array(nameset)==name];old=100*x.sum(axis=1)/e.sum();new=100*np.sum(x*w,axis=1)/np.sum(e*w)
 print(name,'mean abs old/new',np.mean(abs(old)),np.mean(abs(new)),'max abs old/new',max(abs(old)),max(abs(new)))
print('baseline peak squared-error share old/new',e[peak].sum()/e.sum(),np.sum(e[peak]*w[peak])/np.sum(e*w))
from scipy.optimize import minimize
bounds=np.array([PARAMETER_BOUNDS[n] for n in names]);span=bounds[:,1]-bounds[:,0];z0=(x0-bounds[:,0])/span;wm=np.sum(w*obs)/w.sum();den=np.sum(w*(obs-wm)**2)
# Calculate the fixed-weight objective using parameters normalized to their ranges.
def objective(z):
 x=bounds[:,0]+np.clip(z,0,1)*span;r=simulate(m,x)[WARMUP_STEPS:]-obs;return np.sum(w*r*r)/den
def jac(z):
 g=[];h=1e-4
 for i in range(len(z)):
  lo=z.copy();hi=z.copy();lo[i]=max(0,z[i]-h);hi[i]=min(1,z[i]+h);g.append((objective(hi)-objective(lo))/(hi[i]-lo[i]))
 return np.array(g)
from scipy.optimize import differential_evolution
from calibration_config import RANDOM_SEED,MAX_ITERATIONS,POPULATION_MULTIPLIER,RELATIVE_TOLERANCE,POLISH
counter=[0]
def callback(z,convergence):
 counter[0]+=1
 if counter[0]%25==0: print("DE generation",counter[0],"weighted J",objective(z),flush=True)
# Include the original vector as one initial candidate and run 700 DE generations.
r=differential_evolution(objective,[(0,1)]*len(z0),x0=z0,seed=RANDOM_SEED,maxiter=700,popsize=POPULATION_MULTIPLIER,tol=0.0,polish=POLISH,workers=1,callback=callback,strategy='best1bin',updating='immediate',mutation=(0.5,1.0),recombination=0.7,init='latinhypercube',atol=0.0)
q=simulate(m,bounds[:,0]+r.x*span)[WARMUP_STEPS:];base=(obs-obs.mean());nse=lambda v:1-np.sum((v-obs)**2)/np.sum(base**2);peakidx=np.argmax(obs)
print('RECALIBRATION',r.success,r.message,'iterations',r.nit,'evaluations',r.nfev,'weighted J old/new',objective(z0),objective(r.x),'NSE old/new',nse(q0),nse(q),'peak observed/old/new',obs[peakidx],q0[peakidx],q[peakidx],flush=True)

# Retest the three parameters around the new solution.
xnew=bounds[:,0]+r.x*span;baseline_new=objective(r.x)
for name in targets:
 i=names.index(name);x=xnew[i];low,high=PARAMETER_BOUNDS[name];lo=max(.8*x,low);hi=min(1.2*x,high);changes=[]
 for v in np.r_[np.linspace(lo,x,11)[:10],np.linspace(x,hi,11)[1:]]:
  z=xnew.copy();z[i]=v;z=(z-bounds[:,0])/span;changes.append(100*(objective(z)/baseline_new-1))
 print('NEW SENSITIVITY',name,'max absolute',max(abs(np.array(changes))),'average',np.mean(abs(np.array(changes))),flush=True)
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
fig,axes=plt.subplots(2,1,figsize=(12,7),layout='constrained')
for ax in axes:
 ax.plot(d.index,obs,color='black',lw=1.1,label='Observed')
 ax.plot(d.index,q0,color='#0085ad',lw=1.25,label='Original calibration')
 ax.plot(d.index,q,color='#d45b1d',lw=1.25,label='Weighted DE, 700 generations')
 ax.grid(alpha=.2);ax.set_ylabel('Discharge (m³/s)');ax.legend()
axes[0].set_title('Observed and simulated discharge: full period')
axes[1].set_xlim(pd.Timestamp('2011-01-05'),pd.Timestamp('2011-01-21'));axes[1].set_title('January flood events (enlarged)')
fig.savefig(root/'weighted_de_700_reproduced.png',dpi=180);print('SAVED /private/tmp/mmuq_weighted_de_700_fit.png',flush=True)
