# Assignment 2: reproducing the current report

This folder retains the model copy, scripts, and outputs required for the current report. `Assignment1_baseline` provides the model, forcing data, parameter bounds, and original calibrated vector.

Suggested order:

1. `python3 run_sensitivity.py`: one-at-a-time perturbations for 18 parameters; writes `sensitivity_results/perturbations.csv` and curves.
2. `python3 rank_sensitivity.py`: calculate the ranking from those results.
3. `python3 plot_report_curves.py`: create the two nine-parameter figures used in the report.
4. `python3 plot_hydrograph_comparison.py`: generate hydrograph comparisons for the three leading parameters.
5. `python3 run_combined_experiment.py`: run combined perturbations for the three parameters.
6. `python3 run_weighted_de_700.py`: reconstruct weights and run 700 generations of differential evolution; this is time-consuming, prints results to the terminal, and saves `weighted_de_700_reproduced.png`.
7. `python3 run_absolute_de.py`: run 700-generation calibration with absolute error; this is time-consuming and saves `absolute_de_reproduced_fit.png` and `absolute_de_reproduced_result.npz`.

Install dependencies from `Assignment1_baseline/requirements.txt` first. Scripts may overwrite files with the same names; numerical results may vary slightly with software versions. Reaching a generation limit does not establish a global optimum.

`weighted_de_700`, `absolute_de_results`, and `sensitivity_results` retain the existing results. The report LaTeX and figure assets are in the adjacent `document for assignment 2 English` folder. To rebuild, copy regenerated figures into its `figures` folder and compile with XeLaTeX. Earlier exploratory scripts and results are in the adjacent `Assignment 2 English code archive`; they are not part of the current report workflow.
